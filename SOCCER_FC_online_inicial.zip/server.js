const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const path = require("path");

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: "/ws" });

app.use(express.static(__dirname));
app.get("/", (_req, res) => res.sendFile(path.join(__dirname, "index.html")));

const rooms = new Map();

function roomPlayers(room) {
  return rooms.get(room) || new Map();
}
function broadcast(room) {
  const players = Object.fromEntries(roomPlayers(room));
  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN && client.room === room) {
      client.send(JSON.stringify({ type: "state", players }));
    }
  }
}

wss.on("connection", (ws) => {
  ws.on("message", (raw) => {
    let data;
    try { data = JSON.parse(raw.toString()); } catch { return; }

    if (data.type === "join") {
      ws.playerId = String(data.id || Math.random().toString(36).slice(2, 8));
      ws.room = String(data.room || "PUBLIC").trim().slice(0, 12) || "PUBLIC";
      if (!rooms.has(ws.room)) rooms.set(ws.room, new Map());
      roomPlayers(ws.room).set(ws.playerId, {
        id: ws.playerId,
        name: String(data.name || "Jogador").slice(0, 16),
        x: 0, z: 4
      });
      broadcast(ws.room);
      return;
    }

    if (data.type === "move" && ws.room && ws.playerId) {
      const players = roomPlayers(ws.room);
      const old = players.get(ws.playerId);
      if (!old) return;
      old.x = Math.max(-21, Math.min(21, Number(data.x) || 0));
      old.z = Math.max(-12, Math.min(12, Number(data.z) || 0));
      old.name = String(data.name || old.name).slice(0, 16);
      broadcast(ws.room);
    }
  });

  ws.on("close", () => {
    if (!ws.room || !ws.playerId) return;
    const players = roomPlayers(ws.room);
    players.delete(ws.playerId);
    if (players.size === 0) rooms.delete(ws.room);
    else broadcast(ws.room);
  });
});

const port = process.env.PORT || 3000;
server.listen(port, "0.0.0.0", () => {
  console.log(`SOCCER FC rodando na porta ${port}`);
});
