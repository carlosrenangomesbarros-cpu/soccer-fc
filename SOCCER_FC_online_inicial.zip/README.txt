# SOCCER FC — versão online inicial

## O que tem neste pacote
- `index.html`: jogo que você enviou.
- `server.js`: servidor que conecta jogadores por sala e transmite as posições.
- `package.json`: dependências e comando de inicialização.

## Como publicar
1. Coloque os três arquivos na mesma pasta de um repositório GitHub.
2. No Render, crie um **New Web Service** e conecte esse repositório.
3. Escolha **Node** como ambiente.
4. Build Command: `npm install`
5. Start Command: `npm start`
6. Publique e abra a URL HTTPS gerada pelo Render.

## Como seus amigos entram
Todos abrem a mesma URL HTTPS do jogo. Para jogar juntos, escrevam o mesmo código no campo
`Código da sala` (por exemplo `RENAN1`) e toquem em **ENTRAR ONLINE**.
Se deixarem o código vazio, entram na sala pública `PUBLIC`.

## Importante
Esta é uma primeira versão multiplayer: o servidor sincroniza a presença e a posição dos
jogadores. A bola, o placar e a partida ainda são simulados localmente em cada celular;
o próximo passo é sincronizar bola, gols e equipes no servidor para todos verem a mesma partida.
